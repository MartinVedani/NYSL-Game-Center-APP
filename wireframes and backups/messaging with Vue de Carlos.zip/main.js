// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDzfGrAbmsc5dT7Lq99oEYNFB4FHemigQM",
    authDomain: "chatapp-mind.firebaseapp.com",
    databaseURL: "https://chatapp-mind.firebaseio.com",
    projectId: "chatapp-mind",
    storageBucket: "chatapp-mind.appspot.com",
    messagingSenderId: "366227783184",
    appId: "1:366227783184:web:923cf83fa52f8203cd1495"
  };
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

var app = new Vue({
    el: "#app",
    data: {
        mensaje: '',
        mensajes: [],
        userName: '',
        password: '',
        user: null,
    },
    methods: {
        enviar: function(){
            var datos = {
                texto: this.mensaje 
            };
            firebase.database().ref('mensajes').push(datos);
        },
        signIn: function(){
            var provider = new firebase.auth.GoogleAuthProvider();
            firebase.auth().signInWithPopup(provider).then(function(result) {
                // This gives you a Google Access Token.
                var token = result.credential.accessToken;
                // The signed-in user info.
                var user = result.user;
                alert("Listo papá!!")
            });
        },
        signInEmail: function(){
            firebase.auth().createUserWithEmailAndPassword(this.userName, this.password).then(function(userData){
                app.user = userData.user.email;
            }).catch(function(error){
                alert(error.message)
            });
        },
        logInEmail: function(){
            firebase.auth().signInWithEmailAndPassword(this.userName, this.password).then(function(userData){
                app.user = userData.user.email;
            }).catch(function(error){
                alert(error.message)
            });
        },
        signOut: function(){
            firebase.auth().signOut().then(function(){
                alert("Listo, nos vemos!!!");
            });
        }
    }
});

firebase.database().ref('mensajes').on('child_added', function(childSnapshot, prevChildKey) {
    app.mensajes.push(childSnapshot.val())
});

firebase.auth().onAuthStateChanged(function(user){
    if (user) {
        app.user = user.email;
    }else{
        app.user = null;
    }
})